# 斑馬線道路風險評估｜GitHub Pages

## 檔案配置

請將模型檔 `best.onnx` 放在 `index.html` 同一層：

```
/
├── index.html
├── best.onnx
└── .nojekyll
```

目前這份網站包不包含 `best.onnx`，請使用你訓練／匯出的 YOLO26n ONNX 權重檔補上。網頁會從相對路徑 `./best.onnx` 載入模型。

## 發佈到 GitHub Pages

1. 在 GitHub 建立一個新的 **Public** repository（例如 `crosswalk-risk-checker`）。
2. 將 `index.html`、`.nojekyll`、`best.onnx` 放在 repository 根目錄並推送到 `main` 分支。
3. 開啟 repository 的 **Settings → Pages**。
4. 在 **Build and deployment** 選擇 **Deploy from a branch**。
5. Branch 選 `main`、資料夾選 `/(root)`，按 **Save**。
6. 等待 Pages 顯示網站網址，格式通常為 `https://<GitHub帳號>.github.io/<repository名稱>/`。

## 本機測試

請在此資料夾啟動本機 HTTP server（不要直接用 `file://` 開啟），例如：

```bash
python -m http.server 8000
```

瀏覽 `http://localhost:8000/`。

## 注意事項

- 網站採瀏覽器端 ONNX Runtime Web 推論；使用者選取的照片不會被此頁面程式上傳。
- ONNX Runtime Web 由 jsDelivr CDN 載入，因此使用時需要網路連線。
- `best.onnx` 必須能由靜態網站直接讀取；若模型檔過大，需考慮 Git LFS、外部靜態檔案主機或其他模型託管方式，並同步修改 `MODEL_PATH`。
- 此工具為教學示範，評分門檻僅供初步參考，不能取代現場勘查。
